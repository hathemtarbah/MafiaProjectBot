package Main;

public class Doctor extends Roles{

	Doctor(){
		this.name = "Doctor";
		this.description = "The Doctor chooses someone to save each night. "
				+ "That person will not die if they are killed the same night as the Doctor visits, "
				+ "or if they were toasted the previous night. The Doctor is a top-level medic, "
				+ "but is working alone and can only save one person per night. Some say he has a fear of dying "
				+ "and has been known to save himself more than others. What a guy, huh?";
		this.side = "Village";
		this.objective = "Save the mafia's victims";
		this.alive = true;
	}
}
