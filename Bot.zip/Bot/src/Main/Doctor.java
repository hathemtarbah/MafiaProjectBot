package Main;

import java.util.ArrayList;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Emoji;

public class Doctor extends HasActions{
	
	private Roles previous;
	
	Doctor(){
		this.name = "Doctor";
		this.description = "The Doctor chooses someone to save each night. "
				+ "That person will not die if they are killed the same night as the Doctor visits, "
				+ "or if they were toasted the previous night. The Doctor is a top-level medic, "
				+ "but is working alone and can only save one person per night. Some say he has a fear of dying "
				+ "and has been known to save himself more than others. What a guy, huh?";
		this.side = "Village";
		this.objective = "Save the mafia's victims & vote out the mafia side";
		this.alive = true;
		this.desc = "Choose Someone to save tonight, you cannot save the same person two nights in a row";
		this.canKill = false;
	}
	
	
	@Override
	protected void sendMessage(EmbedBuilder eb, ArrayList<Roles> players, String[] emojis) {
		int temp = 0;
		for(Roles p : players) {
			if(p.getUser() != null) {
				if(previous != null) {
					if(p.getUser() == previous.getUser()) {
						
					}
					else {
						eb.addField("",p.getUser().getAsMention() +" "+ Emoji.fromUnicode(emojis[temp]).getName() ,false); 
						temp++;
					}
				}
				else if(previous == null) {
					eb.addField("",p.getUser().getAsMention() +" "+ Emoji.fromUnicode(emojis[temp]).getName() ,false); 
					temp++;
				}
			}
		}
	}
	
	@Override
	public Roles getSelect() {
		if(select == null) {
			channel.sendMessage("You saved no one for the night").queue();
		}
		else if (select != null) {
			channel.sendMessage("You chose to save " + select.getUser().getEffectiveName()).queue();
		}
		return select;
	}
	
	@Override
	public void reset() {
		if(select == null) {
			this.previous = null;
		}else {
			this.previous = select;
		}
		this.select = null;
	}
}
