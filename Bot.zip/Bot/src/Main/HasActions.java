package Main;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Emoji;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.entities.MessageReaction;

abstract class HasActions extends Roles{

	protected String desc;
	protected String msg;
	protected Roles select;

	public void Select(ArrayList<Roles> players, String[] emojis) {
		
		EmbedBuilder eb = new EmbedBuilder();
		eb.setTitle(desc);
		
		sendMessage(eb, players, emojis);

		if(channel != null) {
			channel.sendMessageEmbeds(eb.build()).queue(message -> {
				MessageEmbed ebm = message.getEmbeds().get(0);
				int count = 0;
				for(MessageEmbed.Field f : ebm.getFields()) {
					message.addReaction(Emoji.fromUnicode(emojis[count]).getName()).queue();
					count++;
				}
				msg = message.getId();
			});
			eb.clear();	
		}
	}
	
	protected void sendMessage(EmbedBuilder eb, ArrayList<Roles> players, String[] emojis) {
		int temp = 0;
		for(Roles p : players) {
			if(p.getUser() != null && p != this) {
				
				eb.addField("",p.getUser().getAsMention() +" "+ Emoji.fromUnicode(emojis[temp]).getName() ,false);
				temp++;
				}
		}
	}
	
	public void SetSelect(ArrayList<Roles> players) {
		if(msg != null) {
			channel.retrieveMessageById(msg).queue(message -> {
				List<MessageReaction> reactions = message.getReactions();
				int count = 0;
				for(int i = 0; i < reactions.size(); i++) {
					if(reactions.get(i).getCount()-1 > 0) {
						count++;
					}
				}
				if(count == 1) {
					for(int i = 0; i < reactions.size(); i++) {
						if(reactions.get(i).getCount()-1 == 1) {
							String[] content = message.getEmbeds().get(0).getFields().get(i).getValue().split(" ");
							String temp = content[0];
							for(Roles p : players) {
								if(p.getUser().getAsMention().equals(temp)) {
									select = p;
									break;
								}
							}
							break;
						}
					}
				}
			});
		}
	}
	
	public Roles getSelect() {
		return select;
	}
	
	public void reset() {
		this.select = null;
	}

}
