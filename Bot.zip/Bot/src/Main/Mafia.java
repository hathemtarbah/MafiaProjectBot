package Main;

public class Mafia extends Roles{
	
	public Mafia(){
		this.name = "Mafia";
		this.description = "The regular Mafia (often called Reg) kills someone every night. "
				+ "These fellas are a family like you’ve never seen, and you wouldn’t suspect that they stay up all night deciding who’s life to ruin.";
		this.side = "Mafia";
		this.objective = "Kill the villagers side";
		this.alive = true;
	}
}
