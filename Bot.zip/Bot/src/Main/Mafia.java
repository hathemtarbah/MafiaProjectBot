package Main;

public class Mafia extends MafiaRole{
	
	Mafia(){
		this.name = "Mafia";
	}
	
	public void kill(Player target) {
		
	}
}
