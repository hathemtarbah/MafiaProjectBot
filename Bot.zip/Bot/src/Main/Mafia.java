package Main;

import java.util.ArrayList;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Emoji;

public class Mafia extends HasActions{
	
	public Mafia(){
		this.name = "Mafia";
		this.description = "The regular Mafia (often called Reg) kills someone every night. "
				+ "These fellas are a family like you’ve never seen, and you wouldn’t suspect that they stay up all night deciding who’s life to ruin.";
		this.side = "Mafia";
		this.objective = "Kill the villagers side";
		this.alive = true;
		this.desc = "Choose someone to Kill tonight";
		this.canKill = true;
	}
	
	@Override
	protected void sendMessage(EmbedBuilder eb, ArrayList<Roles> players, String[] emojis) {
		int temp = 0;
		for(Roles p : players) {
			if(p.getUser() != null && p != this && !p.getSide().equals("Mafia")) {eb.addField("",p.getUser().getAsMention() +" "+ Emoji.fromUnicode(emojis[temp]).getName() ,false); temp++;}
		}
	}
	
	@Override
	public Roles getSelect() {
		if(select == null) {
			channel.sendMessage("You chose to kill no one tonight").queue();
			}
		else if (select != null) {
			channel.sendMessage("You chose to Kill " + select.getUser().getEffectiveName()).queue();
			}
		return select;
	}
}
