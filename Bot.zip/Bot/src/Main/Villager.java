package Main;

public class Villager extends MafiaRole{
	
	Villager(){
		this.name = "Villager";
	}
}
