package Main;

import net.dv8tion.jda.api.entities.Member;

public class Villager extends NoActions{
	
	Villager(Member u){
		this.name = "Villager";
		this.user = u;
		this.description = "The Villager is the basic building block of the game and an important member "
				+ "of the Village for voting blocks and figuring out who the Mafia is. The Villager doesn’t "
				+ "have any role actions to complete at night, but that’s not a bad thing! The Villager can "
				+ "focus on the chat and try to figure out who is the most suspicious.";
		this.side = "Village";
		this.objective = "Vote the mafias out";
		this.alive = true;
		this.canKill = false;
	}
}
