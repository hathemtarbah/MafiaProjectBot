package Main;

public class GodFather extends Roles{

	public GodFather(){
		this.name = "GodFather";
		this.description = "The Godfather is a powerful member of the mafia as he cannot be found by the Cops. "
				+ "He appears innocent when investigated. The Godfather can kill someone every night, "
				+ "but it’s best to let regular Mafia do the killing if they are still alive. "
				+ "This is because the GF can be caught by the Creeper, and also because you risk hitting Granny "
				+ "and it is worse to lose GF than regular Mafia. ";
		this.side = "Mafia";
		this.objective = "Kill the villagers side";
		this.alive = true;
	}
}
