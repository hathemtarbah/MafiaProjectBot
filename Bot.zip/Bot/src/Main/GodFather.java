package Main;

import java.util.ArrayList;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Emoji;

public class GodFather extends HasActions{
	
	public GodFather(){
		this.name = "GodFather";
		this.description = "The Godfather is a powerful member of the mafia as he cannot be found by the Cops. "
				+ "He appears innocent when investigated. The Godfather can kill someone every night, "
				+ "but it’s best to let regular Mafia do the killing if they are still alive. "
				+ "This is because the GF can be caught by the Creeper, and also because you risk hitting Granny "
				+ "and it is worse to lose GF than regular Mafia. ";
		this.side = "Mafia";
		this.objective = "Kill the village side";
		this.alive = true;
		this.desc = "Choose Someone to kill tonight";
		this.canKill = true;
	}
	
	@Override
	protected void sendMessage(EmbedBuilder eb, ArrayList<Roles> players, String[] emojis) {
		int temp = 0;
		for(Roles p : players) {
			if(p.getUser() != null && p != this && !p.getSide().equals("Mafia")) {eb.addField("",p.getUser().getAsMention() +" "+ Emoji.fromUnicode(emojis[temp]).getName() ,false); temp++;}
		}
	}
	
	@Override
	public Roles getSelect() {
		if(select == null) {
			channel.sendMessage("You chose to kill no one tonight").queue();
			}
		else if (select != null) {
			channel.sendMessage("You chose to Kill " + select.getUser().getEffectiveName()).queue();
			}
		return select;
	}

}
