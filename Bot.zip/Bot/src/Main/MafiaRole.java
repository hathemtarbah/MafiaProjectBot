package Main;

abstract class MafiaRole {
	protected String name;
	
	public String getName() {
		return name;
	}
}
