package Main;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Category;
import net.dv8tion.jda.api.entities.Channel;
import net.dv8tion.jda.api.entities.Emoji;
import net.dv8tion.jda.api.entities.GuildChannel;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.entities.PrivateChannel;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class Game extends ListenerAdapter{
	private ArrayList<Member> members;
	private ArrayList<Roles> players = new ArrayList<>();
	private String[] emojis = {"U+1F1E6", "U+1F1E7", "U+1F1E8", "U+1F1E9", "U+1F1EA", "U+1F1EB", "U+1F1EC",
			"U+1F1ED", "U+1F1EE", "U+1F1EF", "U+1F1F0","U+1F1F1","U+1F1F2","U+1F1F3","U+1F1F4","U+1F1F5",
			"U+1F1F6","U+1F1F7","U+1F1F8","U+1F1F9","U+1F1FA","U+1F1FB","U+1F1FC","U+1F1FD","U+1F1FE","U+1F1FF"};
	private int gameState = 0;
	EmbedBuilder embedBuilder = new EmbedBuilder();
	private String catId;
	private MessageReceivedEvent event;
	private Member host;
	private MessageChannel voteChannel;
	private MessageChannel gameChannel;
	
	
	Game(ArrayList<Member> p, MessageReceivedEvent e){
		this.event = e;
		event.getGuild().getEmotes();
		this.members = p;
		this.host = members.get(0);
		assignRoles();
		createChannels(event);
	}
	
	private void createChannels(MessageReceivedEvent event) {
		event.getGuild().createCategory("Mafia").queue(c -> {
			catId = c.getId();
			c.createTextChannel("Game Chat").queue(channel -> gameChannel = channel);
			c.createTextChannel("Votes").queue(channel -> voteChannel = channel);
			c.createVoiceChannel("Chat").queue();
			c.createVoiceChannel("Graveyard").queue();
		});
	}
	
	private void deleteChannels(MessageReceivedEvent event) {
		if(catId != null) {
			if(event.getGuild().getCategoryById(catId) != null) {
				Category cat = event.getGuild().getCategoryById(catId);
				List<GuildChannel> channels = cat.getChannels();
				for(GuildChannel c : channels) {
					c.delete().queue();
				}
				cat.delete().queue();;
			}
		}
	}
	
	private void assignRoles() {
		ArrayList<Member> temp = members;
		players.add(new GodFather());
		players.add(new Cop());
		players.add(new Doctor());
		players.add(new Mafia());
		Random rand = new Random();
		int num = 0;
		
		for(Roles role : players) {
			if(temp.size()>0) {
				num = rand.nextInt(temp.size());
				role.setUser(temp.get(num));
				temp.remove(num);
			}
		}

		for(Member m : temp) {
			players.add(new Villager(m));
		}
		
		if(players != null) {
			for(Roles p : players) {
				if(p.getUser() != null) {
					embedBuilder.setTitle("Role: "+p.getName());
					embedBuilder.addField("Description", p.getDesc(), false);
					embedBuilder.addField("Side", p.getSide(), false);
					embedBuilder.addField("Objective", p.getObj(), false);
					embedBuilder.setColor(Color.green);
					PrivateChannel channel = p.getUser().getUser().openPrivateChannel().complete();
					channel.sendMessageEmbeds(embedBuilder.build()).queue();
					embedBuilder.clear();
				}
			}
		}
	}
	
	private void voting() {
		embedBuilder.setTitle("Voting Time");
		embedBuilder.setDescription("Description");
		for(int i = 0; i < players.size(); i++) {
			if(players.get(i).getUser() != null) embedBuilder.addField("",players.get(i).getUser().getAsMention() +' '+ Emoji.fromUnicode(emojis[i]).getName() ,false);
		}
		if(voteChannel != null) {
			voteChannel.sendMessageEmbeds(embedBuilder.build()).queue(message -> {
				for(int i = 0; i < players.size(); i++) {
					message.addReaction(Emoji.fromUnicode(emojis[i]).getName()).queue();
				}
			});
		}
		embedBuilder.clear();
		
	}
	
	@Override
	public void onMessageReceived(MessageReceivedEvent event) {
		String prefix = "!";
		Message msg = event.getMessage();
		if(msg.getContentRaw().equals(prefix+"mstart")) {
			if(event.getAuthor().isBot()) {
				return;
			}
			if(event.getAuthor() == host.getUser()) {
				voting();
			}
			else {
				msg.reply("Only the host ("+host.getEffectiveName()+") can start the game").queue();
			}
		}
		
		else if(msg.getContentRaw().equals(prefix+"dch")) {
			deleteChannels(event);
		}
	}
	
}
