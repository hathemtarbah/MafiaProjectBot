package Main;

import java.awt.Color;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Category;
import net.dv8tion.jda.api.entities.Emoji;
import net.dv8tion.jda.api.entities.GuildChannel;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageReaction;
import net.dv8tion.jda.api.entities.PrivateChannel;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.TextChannel;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class Game extends ListenerAdapter{
	private ArrayList<Member> members;
	private static ArrayList<Roles> players = new ArrayList<>();
	private ArrayList<Roles> deadPlayers = new ArrayList<>();
	private String[] emojis = {"U+1F1E6", "U+1F1E7", "U+1F1E8", "U+1F1E9", "U+1F1EA", "U+1F1EB", "U+1F1EC",
			"U+1F1ED", "U+1F1EE", "U+1F1EF", "U+1F1F0","U+1F1F1","U+1F1F2","U+1F1F3","U+1F1F4","U+1F1F5",
			"U+1F1F6","U+1F1F7","U+1F1F8","U+1F1F9","U+1F1FA","U+1F1FB","U+1F1FC","U+1F1FD","U+1F1FE","U+1F1FF"};
	private int gameState = 0;
	EmbedBuilder embedBuilder = new EmbedBuilder();
	private String catId;
	private MessageReceivedEvent event;
	private Member host;
	private TextChannel voteChannel;
	private TextChannel gameChannel;
	private TextChannel mafiaChannel;
	private Role aliveRoleId;
	private Role deadRoleId;
	private int mafiaSide;
	private final int actionTimer = 30;
	
	private String voteMessage;
	private String timerMessage;
	Game(ArrayList<Member> p, MessageReceivedEvent e){
		this.event = e;
		this.members = p;
		this.host = members.get(0);
		
		Timer timer = new Timer();
		TimerTask task = new TimerTask() {
			int count = 10;

			@Override
			public void run() {
				if(count == 10) {
					createRoles();
					createChannels(e);
				}
				
				if(count == 7) {
					assignRoles();
				}
				if(count == 4) {
					timer.cancel();
				}
				count--;
			}
		};
		timer.scheduleAtFixedRate(task, 0, 1000);

	}
	

	
	private void createRoles() {
		this.aliveRoleId =event.getGuild().createRole()
				.setName("Mafia Game")
				.setHoisted(false)
				.setMentionable(true)
				.complete();
	
		this.deadRoleId =event.getGuild().createRole()
				.setName("Mafia Game")
				.setHoisted(false)
				.setMentionable(false)
				.complete();
		
		for(Member m : members) {
			if(aliveRoleId != null) event.getGuild().addRoleToMember(m, aliveRoleId).queue();
		}
	}
	
	private void createChannels(MessageReceivedEvent event) {
		
		event.getGuild().createCategory("Mafia").queue(c -> {
			EnumSet<Permission> textPermissions = EnumSet.of(Permission.VIEW_CHANNEL,Permission.MESSAGE_SEND, Permission.MESSAGE_ADD_REACTION);
			EnumSet<Permission> voicePermissions = EnumSet.of(Permission.VIEW_CHANNEL,Permission.VOICE_CONNECT, Permission.VOICE_SPEAK);
			catId = c.getId();
			
			c.createTextChannel("Game Chat").addPermissionOverride(aliveRoleId, textPermissions, null)
				.addPermissionOverride(deadRoleId, EnumSet.of(Permission.VIEW_CHANNEL), textPermissions)
				.addPermissionOverride(event.getGuild().getPublicRole(), null , textPermissions)
				.queue(channel -> {
					this.gameChannel = channel;
					channel.getManager().queue();
				});
	
			c.createTextChannel("Mafia Chat")
				.addPermissionOverride(deadRoleId, EnumSet.of(Permission.VIEW_CHANNEL), textPermissions)
				.addPermissionOverride(event.getGuild().getPublicRole(), null , textPermissions)
				.queue(channel -> {
					mafiaChannel = channel;
					channel.getManager().queue();
				});
			
			c.createTextChannel("Votes").addPermissionOverride(aliveRoleId,textPermissions,null)
				.addPermissionOverride(deadRoleId, EnumSet.of(Permission.VIEW_CHANNEL), textPermissions)
				.addPermissionOverride(event.getGuild().getPublicRole(), null , textPermissions)
				.queue(channel -> {
					this.voteChannel = channel;
					channel.getManager().queue();
				});
	
			c.createVoiceChannel("Chat").addPermissionOverride(aliveRoleId,voicePermissions,null)
				.addPermissionOverride(deadRoleId, null, voicePermissions)
				.addPermissionOverride(event.getGuild().getPublicRole(), null , voicePermissions)
				.queue(channel -> {
					channel.getManager().queue();
				});
	
			c.createVoiceChannel("Graveyard").addPermissionOverride(deadRoleId,voicePermissions,null)
				.addPermissionOverride(aliveRoleId, null, voicePermissions)
				.addPermissionOverride(event.getGuild().getPublicRole(), null , voicePermissions)
				.queue(channel -> {
					channel.getManager().queue();
				});
			
		});
		
	}
	
	private void deleteChannels(MessageReceivedEvent event) {
		if(catId != null) {
			if(event.getGuild().getCategoryById(catId) != null) {
				Category cat = event.getGuild().getCategoryById(catId);
				List<GuildChannel> channels = cat.getChannels();
				for(GuildChannel c : channels) {
					c.delete().queue();
				}
				cat.delete().queue();;
			}
		}
	}
	
	private void deleteRoles() {
		for(Member m : members) {
			if(m.getRoles().contains(aliveRoleId)) {
				event.getGuild().removeRoleFromMember(m,aliveRoleId).queue();
			}
			else if(m.getRoles().contains(deadRoleId)) {
				event.getGuild().removeRoleFromMember(m,deadRoleId).queue();
			}
		}
		if(aliveRoleId != null)aliveRoleId.delete().queue();
		if(deadRoleId != null)deadRoleId.delete().queue();
	}
	 
	
	private void assignRoles() {
		ArrayList<Member> temp = members;
		
		if(members.size() <= 6) {
			players.add(new Mafia());
		}
		else if(members.size() > 6 && members.size() < 9) {
			players.add(new Mafia());
			players.add(new GodFather());
		}
		else if(members.size() >= 9 && members.size() <= 12) {
			players.add(new Mafia());
			players.add(new Mafia());
			players.add(new GodFather());
		}
		else if(members.size() > 12 && members.size() <= 15) {
			players.add(new Mafia());
			players.add(new Mafia());
			players.add(new Mafia());
			players.add(new GodFather());
		}
		else if(members.size() > 15 && members.size() <= 20) {
			players.add(new Mafia());
			players.add(new Mafia());
			players.add(new Mafia());
			players.add(new Mafia());
			players.add(new GodFather());
		}
		players.add(new Doctor());
		players.add(new Cop());
		
		Random rand = new Random();
		int num = 0;
		
		for(Roles role : players) {
			if(temp.size()>0) {
				num = rand.nextInt(temp.size());
				role.setUser(temp.get(num));
				temp.remove(num);
			}
		}

		for(Member m : temp) {
			players.add(new Villager(m));
		}
		
		for(Roles p : players) {
			if(p.getSide().equals("Mafia") && p.getUser() != null) {
				if(mafiaChannel != null) {
					mafiaChannel.createPermissionOverride(p.getUser())
						.setAllow(EnumSet.of(Permission.VIEW_CHANNEL, Permission.MESSAGE_SEND, Permission.MESSAGE_ADD_REACTION))
						.queue();
				}
				mafiaSide++;
			}
		}
		

		
		if(players != null) {
			for(Roles p : players) {
				if(p.getUser() != null) {
					embedBuilder.setTitle("Role: "+p.getName());
					embedBuilder.addField("Description", p.getDesc(), false);
					embedBuilder.addField("Side", p.getSide(), false);
					embedBuilder.addField("Objective", p.getObj(), false);
					embedBuilder.setColor(Color.green);
					PrivateChannel channel = p.getUser().getUser().openPrivateChannel().complete();
					p.setChannel(channel);
					p.getChannel().sendMessageEmbeds(embedBuilder.build()).queue();
					embedBuilder.clear();
				}
			}
		}
	}
	
	private void voting(){
		embedBuilder.setTitle("Voting Time");
		embedBuilder.setDescription(aliveRoleId.getAsMention()+"\nTime for everyone still alive to vote for someone to be lynched, if the results are tied, no one is lynched.");
		for(int i = 0; i < players.size(); i++) {
			if(players.get(i).getUser() != null) embedBuilder.addField("",players.get(i).getUser().getAsMention() +' '+ Emoji.fromUnicode(emojis[i]).getName() ,false);
		}
		if(voteChannel != null) {
			voteChannel.sendMessageEmbeds(embedBuilder.build()).queue(message -> {
				for(int i = 0; i < players.size(); i++) {
					if(players.get(i).getUser() != null)message.addReaction(Emoji.fromUnicode(emojis[i]).getName()).queue();
				}
				voteMessage = message.getId();
			});
			embedBuilder.clear();

			voteChannel.sendMessage("Time Remaining : ").queue(message -> timerMessage = message.getId());
			Timer timer = new Timer();
			TimerTask task = new TimerTask(){
				
				int timeLeft = 30;
			    public void run(){
			    	
			    	if(timerMessage != null && timeLeft >= 0)voteChannel.retrieveMessageById(timerMessage).queue(message -> message.editMessage("Time Remaining : "+timeLeft).queue());
			    	timeLeft--;
			    	
			    	if(timeLeft == 0) {
			    		if(voteMessage != null) {
							voteChannel.retrieveMessageById(voteMessage).queue(message -> {
								List<MessageReaction> reactionsList = message.getReactions();
								for(int i = 0; i < reactionsList.size(); i++) {
									if(players.get(i).getUser() != null) {
										
										int count = reactionsList.get(i).getCount() - 1;
										players.get(i).setVote(count);
									}
								}
								
								int temp = players.get(0).getVotes();
								int select = 0;
								boolean tie = false;
								for(int i = 1; i < players.size(); i++) {
									if(players.get(i).getVotes() > temp) { 
										temp = players.get(i).getVotes(); 
										select = i;
									}
								}
								
								for(int i = 0; i < players.size(); i++) {
									if(i != select) {
										if(players.get(select).getVotes() == players.get(i).getVotes()) {
											tie = true;
											break;
										}
									}
								}
								
								if(tie == false) {
									embedBuilder.setTitle("Results");
									embedBuilder.setDescription(players.get(select).getUser().getAsMention() +" was voted out with : "+players.get(select).getVotes()+" Votes");
								    message.getChannel().sendMessageEmbeds(embedBuilder.build()).queue();
								    embedBuilder.clear();
								    playerDeath(players.get(select));
								}
								else if(tie == true) {
									embedBuilder.setTitle("Results");
									embedBuilder.setDescription("The votes were tied so no one was lynched");
									message.getChannel().sendMessageEmbeds(embedBuilder.build()).queue();
								    embedBuilder.clear();
								}
							});
							for(Roles player : players) {
								player.clearVotes();
							}
							timer.cancel();
						}

			    	}
			    
			    }
			};
			
			timer.scheduleAtFixedRate(task, 0, 1000);
		}
	}
	
	private void doActions() {
		if(mafiaSide > 1) {
			embedBuilder.setTitle("Killing");
			embedBuilder.setDescription("Discuss who to kill tonight here and vote in your DMs, if the votes are tied, no one is killed");
			mafiaChannel.sendMessageEmbeds(embedBuilder.build()).queue();
			embedBuilder.clear();
		}
		
		ArrayList<Message> messages = new ArrayList<>();
		
		Timer timer = new Timer();
		TimerTask task = new TimerTask() {
			
			int countdown = actionTimer;
			Roles kill = null;
			Roles save = null;
			
			@Override
			public void run() {
				
				if(countdown == actionTimer) {
					for(Roles player : players) {
						if(player.getUser() != null) {
							if(player instanceof HasActions) {
								((HasActions) player).Select(players, emojis);
								Message m = player.getChannel().sendMessage("Time Remaining : ").complete();
								messages.add(m);
							}
						}
					}
				}
				if(countdown >= 0) {
					for(Message m : messages) {
						m.editMessage("Time Remaining : "+countdown).queue();
					}
				}
				countdown--;
				
				if(countdown == 0) {
					for(Roles p : players) {
						if(p instanceof HasActions) {
							((HasActions) p).SetSelect(players);
						}
					}
				}
				
				if(countdown == -3) {
					ArrayList<Roles> killList = new ArrayList<>();
					//
					for(Roles player : players) {
						if(player.getUser() != null) {
							if(player instanceof HasActions) {
								if(player.getCanKill() == true) {
									killList.add(((HasActions) player).getSelect());
								}
								else if(player instanceof Doctor) {
									save = ((HasActions) player).getSelect();
								}
								else {
									((HasActions) player).getSelect();
								}
								((HasActions) player).reset();
							}
						}
					}
					
					for(Roles target : killList) {
						if(players.contains(target)) {
							players.get(players.indexOf(target)).incrementVote();;
						}
					}
					
					int temp = players.get(0).getVotes();
					int select = 0;
					boolean tie = false;
					for(int i = 1; i < players.size(); i++) {
						if(players.get(i).getVotes() > temp) { 
							temp = players.get(i).getVotes(); 
							select = i;
						}
					}
					
					for(int i = 0; i < players.size(); i++) {
						if(i != select) {
							if(players.get(select).getVotes() == players.get(i).getVotes()) {
								tie = true;
								break;
							}
						}
					}
					
					for(Roles player : players) {
						player.clearVotes();
					}
					
					if(tie == false) {
						kill = players.get(select);
						if(mafiaSide > 1) {
							embedBuilder.setDescription(kill.getUser().getAsMention()+" was chosen to be killed tonight");
							mafiaChannel.sendMessageEmbeds(embedBuilder.build()).queue();
							embedBuilder.clear();
						}
					}
					else {
						embedBuilder.setDescription("No one was chosen to be killed tonight");
						mafiaChannel.sendMessageEmbeds(embedBuilder.build()).queue();
						embedBuilder.clear();
					}
				}
				if(countdown == -6) {
					Summary(kill, save);
					kill = null;
					save = null;
					timer.cancel();
				}
			}
		};
		timer.scheduleAtFixedRate(task, 0, 1000);
	}
	
	private void Summary(Roles killed, Roles saved) {
		embedBuilder.setTitle("Summary");
		
		if(killed != null) {
			if(saved != null) {
				if(saved.getUser().getId().equals(killed.getUser().getId())) {
					embedBuilder.setColor(Color.green);
					embedBuilder.setDescription(killed.getUser().getAsMention()+" was saved from death by the Doctor");
					gameChannel.sendMessageEmbeds(embedBuilder.build()).queue();
					embedBuilder.clear();
				}
			}
			else {
				embedBuilder.setColor(Color.red);
				embedBuilder.setDescription(killed.getUser().getAsMention()+" was killed during the night");
				gameChannel.sendMessageEmbeds(embedBuilder.build()).queue();
				embedBuilder.clear();
				playerDeath(killed);
			}
		}
		else {
			embedBuilder.setColor(Color.blue);
			embedBuilder.setDescription("Nothing happened during the night.");
			gameChannel.sendMessageEmbeds(embedBuilder.build()).queue();
			embedBuilder.clear();
		}
		
		
	}
	
	private void playerDeath(Roles player) {
		
		if(deadRoleId != null) {
			if(!player.getUser().getRoles().contains(deadRoleId)) {
				event.getGuild().addRoleToMember(player.getUser(), deadRoleId).queue();
				event.getGuild().removeRoleFromMember(player.getUser(), aliveRoleId).queue();
			}
		}
		
		if(mafiaSide > 0 && player.getSide().equals("Mafia")) {
	    	mafiaSide--;
	    }
		
		if(players.contains(player)) { 
			deadPlayers.add(player);
			players.remove(player);
		}
	}
	
	private int check() {
		if(mafiaSide >= (players.size()-mafiaSide)) {
			gameState = 1;
		}
		else if(mafiaSide == 0) {
			gameState = 2;
		}
		return gameState;
	}
	
	@Override
	public void onMessageReceived(MessageReceivedEvent event) {
		String prefix = "!";
		Message msg = event.getMessage();
		if(msg.getContentRaw().equals(prefix+"mstart")) {
			if(event.getAuthor().isBot()) {
				return;
			}
			if(event.getAuthor().getId().equals(host.getId()) ) {
				
				embedBuilder.setTitle("Information");
				embedBuilder.setColor(Color.green);
				embedBuilder.setDescription("Intro");
				gameChannel.sendMessageEmbeds(embedBuilder.build()).queue();
				embedBuilder.clear();
				
				Timer timer = new Timer();
				TimerTask task = new TimerTask() {
					
					int count = 205;
					@Override
					public void run() {
						
						if(count == 205) {
							doActions();
						}
						if(count == 165) {
							if(check() == 1) {
								embedBuilder.setColor(Color.red);
								embedBuilder.setTitle("Mafia Side Wins");
								for(Roles p : players) {
									if(p.getSide().equalsIgnoreCase("Mafia"))
									embedBuilder.appendDescription(p.getUser().getAsMention() +"\n");
								}
								for(Roles p : deadPlayers) {
									if(p.getSide().equalsIgnoreCase("Mafia"))
									embedBuilder.appendDescription(p.getUser().getAsMention() +"\n");
								}
								embedBuilder.addField("Game Finished","use \"!dch\" to delete channels",false);
								gameChannel.sendMessageEmbeds(embedBuilder.build()).queue();
								embedBuilder.clear();
								timer.cancel();
							}
							else if(check() == 2) {
								embedBuilder.setColor(Color.green);
								embedBuilder.setTitle("Village Side Wins");
								for(Roles p : players) {
									if(p.getSide().equalsIgnoreCase("Village"))
									embedBuilder.appendDescription(p.getUser().getAsMention() +"\n");
								}
								for(Roles p : deadPlayers) {
									if(p.getSide().equalsIgnoreCase("Village"))
									embedBuilder.appendDescription(p.getUser().getAsMention() +"\n");
								}
								embedBuilder.addField("Game Finished","use \"!dch\" to delete channels",false);
								gameChannel.sendMessageEmbeds(embedBuilder.build()).queue();
								embedBuilder.clear();
								timer.cancel();
							}else {
								embedBuilder.setColor(Color.blue);
								embedBuilder.setTitle("Discussion Time");
								gameChannel.sendMessageEmbeds(embedBuilder.build()).queue();
							}
						}
						if(count == 128) {
							embedBuilder.setColor(Color.blue);
							embedBuilder.setTitle("Voting time, head to the votes channel");
							gameChannel.sendMessageEmbeds(embedBuilder.build()).queue();
							embedBuilder.clear();
							voting();
						}
						if(count == 93) {
							if(check() == 1) {
								embedBuilder.setColor(Color.red);
								embedBuilder.setTitle("Mafia Side Wins");
								for(Roles p : players) {
									if(p.getSide().equalsIgnoreCase("Mafia"))
									embedBuilder.appendDescription(p.getUser().getAsMention() +"\n");
								}
								for(Roles p : deadPlayers) {
									if(p.getSide().equalsIgnoreCase("Mafia"))
									embedBuilder.appendDescription(p.getUser().getAsMention() +"\n");
								}
								embedBuilder.addField("Game Finished","use \"!dch\" to delete channels",false);
								gameChannel.sendMessageEmbeds(embedBuilder.build()).queue();
								embedBuilder.clear();
								timer.cancel();
							}
							else if(check() == 2) {
								embedBuilder.setColor(Color.green);
								embedBuilder.setTitle("Village Side Wins");
								for(Roles p : players) {
									if(p.getSide().equalsIgnoreCase("Village"))
									embedBuilder.appendDescription(p.getUser().getAsMention() +"\n");
								}
								for(Roles p : deadPlayers) {
									if(p.getSide().equalsIgnoreCase("Village"))
									embedBuilder.appendDescription(p.getUser().getAsMention() +"\n");
								}
								embedBuilder.addField("Game Finished","use \"!dch\" to delete channels",false);
								gameChannel.sendMessageEmbeds(embedBuilder.build()).queue();
								embedBuilder.clear();
								timer.cancel();
							}
							else {
								count = 206;
							}
						}
						count--;
					}
					
				};
				timer.scheduleAtFixedRate(task,10000, 1000);
				
			}
			else {
				msg.reply("Only the host ("+host.getEffectiveName()+") can start the game").queue();
			}
		}
		
		else if(msg.getContentRaw().equals(prefix+"dch")) {
			deleteChannels(event);
			deleteRoles();
			event.getJDA().removeEventListener(this);
		}
	}
	
}
