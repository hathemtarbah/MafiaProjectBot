package Main;

import java.awt.Color;
import java.util.ArrayList;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class Commands extends ListenerAdapter{
	ArrayList<Player> players = new ArrayList<>();
	static final int minPlayers = 5;
	EmbedBuilder embed = new EmbedBuilder();
	Member host = null;
	@Override
	public void onMessageReceived(MessageReceivedEvent event) {
		String prefix = "!";
		Message msg = event.getMessage();
		if(msg.getContentRaw().equals(prefix+"mafia")) {
			if(players.isEmpty()) {
				//get user that called event
				host = event.getMember();
				
				//build and send embed
				embed.setTitle("Mafia Game");
				embed.setDescription(host.getAsMention()+" has started a Mafia Game, type \"!mjoin\" to join the game\nHost type \"!mstart\" to start game");
				embed.setColor(Color.red);
				embed.addField("Minimum Players", ""+minPlayers, false);
				event.getChannel().sendMessageEmbeds(embed.build()).queue();
				embed.clear();
				Player player = new Player(host);
				players.add(player);
			}
			else {
				embed.setTitle("Cannot create game");
				embed.setDescription("Another Mafia game is already running");
				embed.setColor(Color.red);
				event.getChannel().sendMessageEmbeds(embed.build()).queue();
				embed.clear();
			}
		}
		
		else if (msg.getContentRaw().equals(prefix+"mjoin")) {
			if(!players.isEmpty()) {
				boolean exists = false;
				for(Player p : players) {
					if(p.getUser() == event.getMember()) {
						exists = true;
						msg.reply("Already Joined!").queue();
						break;
					}
				}
				if(exists == false) {
					Player player = new Player(event.getMember());
					players.add(player);
					embed.setDescription(event.getMember().getEffectiveName()+" Joined the Game!");
					embed.setColor(Color.blue);
					event.getChannel().sendMessageEmbeds(embed.build()).queue();
					embed.clear();
				}
			}
			else {
				msg.reply("No game found").queue();
			}
		}
		
		else if(msg.getContentRaw().equals(prefix+"mstart")) {
			if(host == null) {
				msg.reply("No game found").queue();
			}
			else if(event.getMember() == host) {
				//start game
				if(players.size() >= minPlayers) {
					for(Player p : players) {
						p.getUser().getUser().openPrivateChannel().queue(channel -> channel.sendMessage("Testing").queue());
					}
				}
				else {
					embed.setTitle("Not Enough Players");
					embed.setDescription("Minimum Players : "+minPlayers+"\nCurrently have : "+players.size());
					embed.setColor(Color.blue);
					event.getChannel().sendMessageEmbeds(embed.build()).queue();
					embed.clear();
				}
			}
			else {
				msg.reply("Only the host ("+host.getEffectiveName()+") can start the game").queue();
			}
		}
		
		else if (msg.getContentRaw().equals(prefix + "players") ) {
			embed.setTitle("Joined Players");
        	for(Player p : players) {
        		embed.appendDescription(p.getUser().getAsMention()+"\n");
        	}
        	embed.setColor(Color.blue);
        	event.getChannel().sendMessageEmbeds(embed.build()).queue();
			embed.clear();
        }
		
		else if(msg.getContentRaw().equals(prefix + "mstop")) {
			if(host == null) {
				msg.reply("No active game found").queue();
			}
			else if(event.getMember() == host) {
				embed.setTitle("Game Cancelled");
				embed.setDescription(event.getAuthor().getAsMention()+" has stopped the game");
				embed.setColor(Color.red);
				event.getChannel().sendMessageEmbeds(embed.build()).queue();
				embed.clear();
				host = null;
				players.clear();
			}
			else {
				msg.reply("Only the host can cancel the game").queue();
			}
		}
		
    	else if (msg.getContentRaw().equals(prefix + "vote")) {
            MessageChannel channel = event.getChannel();
            channel.sendMessage("this performs the vote action").queue();
        }
		
        else if (msg.getContentRaw().equals(prefix + "kill")) {
        	MessageChannel channel = event.getChannel();
            channel.sendMessage("this performs the kill action").queue();
        }
		
        else if (msg.getContentRaw().contains(prefix + "investigate") ) {
        	MessageChannel channel = event.getChannel();
        	channel.sendMessage("this performs the investigate action").queue();
        }
	}
}
