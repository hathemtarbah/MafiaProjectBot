package Main;

import java.awt.Color;
import java.util.ArrayList;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class Commands extends ListenerAdapter{
	public static ArrayList<Member> players = new ArrayList<>();
	static final int minPlayers = 1;
	EmbedBuilder embed = new EmbedBuilder();
	public static Member host = null;
	@Override
	public void onMessageReceived(MessageReceivedEvent event) {
		String prefix = "!";
		Message msg = event.getMessage();
		if(msg.getContentRaw().equals(prefix+"mafia")) {
			if(event.getAuthor().isBot()) {
				return;
			}
			if(players.isEmpty()) {
				//get user that called event
				host = event.getMember();
				
				//build and send embed
				embed.setTitle("Mafia Game");
				embed.setDescription(host.getAsMention()+" has started a Mafia Game, type \"!mjoin\" to join the game\nHost type \"!msetup\" to assign roles "
						+ "and then \"!mstart\"  to start the game");
				embed.setColor(Color.red);
				embed.addField("Minimum Players", ""+minPlayers, false);
				event.getChannel().sendMessageEmbeds(embed.build()).queue();
				embed.clear();
				players.add(host);
			}
			else {
				embed.setTitle("Cannot create game");
				embed.setDescription("Another Mafia game is already running");
				embed.setColor(Color.red);
				event.getChannel().sendMessageEmbeds(embed.build()).queue();
				embed.clear();
			}
		}
		
		else if (msg.getContentRaw().equals(prefix+"mjoin")) {
			if(event.getAuthor().isBot()) {
				return;
			}
			if(!players.isEmpty()) {
				boolean exists = false;
				for(Member p : players) {
					if(p == event.getMember()) {
						exists = true;
						msg.reply("Already Joined!").queue();
						break;
					}
				}
				if(exists == false) {
					players.add(event.getMember());
					embed.setDescription(event.getMember().getEffectiveName()+" Joined the Game!");
					embed.setColor(Color.blue);
					event.getChannel().sendMessageEmbeds(embed.build()).queue();
					embed.clear();
				}
			}
			else {
				msg.reply("No game found").queue();
			}
		}
		
		else if(msg.getContentRaw().equals(prefix+"msetup")) {
			if(host == null) {
				msg.reply("No game found").queue();
			}
			else if(event.getMember() == host) {
				//start game
				if(players.size() >= minPlayers) {
					event.getJDA().addEventListener(new Game(players, event));
				}
				else {
					embed.setTitle("Not Enough Players");
					embed.setDescription("Minimum Players : "+minPlayers+"\nCurrently have : "+players.size());
					embed.setColor(Color.blue);
					event.getChannel().sendMessageEmbeds(embed.build()).queue();
					embed.clear();
				}
			}
			else {
				msg.reply("Only the host ("+host.getEffectiveName()+") can setup the game").queue();
			}
		}
		
		else if (msg.getContentRaw().equals(prefix + "players") ) {
			embed.setTitle("Joined Players");
        	for(Member p : players) {
        		embed.appendDescription(p.getAsMention()+"\n");
        	}
        	embed.setColor(Color.blue);
        	event.getChannel().sendMessageEmbeds(embed.build()).queue();
			embed.clear();
        }
		
		else if(msg.getContentRaw().equals(prefix + "mstop")) {
			if(host == null) {
				msg.reply("No active game found").queue();
			}
			else if(event.getMember() == host) {
				embed.setTitle("Game Cancelled");
				embed.setDescription(event.getAuthor().getAsMention()+" has stopped the game");
				embed.setColor(Color.red);
				event.getChannel().sendMessageEmbeds(embed.build()).queue();
				embed.clear();
				host = null;
				players.clear();
			}
			else {
				msg.reply("Only the host can cancel the game").queue();
			}
		}
		
		else if(msg.getContentRaw().equals(prefix+"commands")) {
			embed.setTitle("Commands List");
			embed.addField("!mafia","Creates a mafia lobby for people to join",false);
			embed.addField("!mjoin","Joins lobby",false);
			embed.addField("!msetup","Only the host can use, assigns roles and creates channels for the game",false);
			embed.addField("!mstart","Can only be used by host after calling \"!msetup\", starts the game",false);
			embed.addField("!mstop","Only host can use. Cancels game",false);
			embed.addField("!players","Displays all joined players",false);
			embed.addField("!commands","Shows command list",false);
			embed.setColor(Color.blue);
			event.getChannel().sendMessageEmbeds(embed.build()).queue();
			embed.clear();
		}
	}
}
