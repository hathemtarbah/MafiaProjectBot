package Main;

import net.dv8tion.jda.api.entities.Emoji;
import net.dv8tion.jda.api.events.message.react.MessageReactionAddEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class Voting extends ListenerAdapter{
	
	Voting(){
		
	}
	@Override
	public void onMessageReactionAdd(MessageReactionAddEvent event) {
		if(event.getUser().isBot()) {
			return;
		}
		if(event.getReactionEmote().getName().equals(Emoji.fromUnicode("U+1F1E6").getName())) {
			event.getChannel().sendMessage("it Works!").queue();
		}
	}
}
