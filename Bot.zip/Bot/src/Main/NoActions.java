package Main;

abstract class NoActions extends Roles{

}
