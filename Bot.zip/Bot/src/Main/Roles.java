package Main;

import net.dv8tion.jda.api.entities.Member;

abstract class Roles {
	protected String name;
	protected Member user;
	protected String description;
	protected String side;
	protected String objective;
	boolean alive;
	
	public String getName() {
		return name;
	}
	public Member getUser() {
		return user;
	}
	public String getDesc() {
		return description;
	}
	public String getSide() {
		return side;
	}
	public String getObj() {
		return objective;
	}
	public void setUser(Member u) {
		user = u;
	}
}
