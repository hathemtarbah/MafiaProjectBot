package Main;

import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.PrivateChannel;

abstract class Roles {
	protected String name;
	protected Member user;
	protected String description;
	protected String side;
	protected String objective;
	boolean alive;
	protected int votes;
	protected PrivateChannel channel;
	protected boolean canKill;
	
	public String getName() {
		return name;
	}
	public Member getUser() {
		return user;
	}
	public String getDesc() {
		return description;
	}
	public String getSide() {
		return side;
	}
	public String getObj() {
		return objective;
	}
	public void setUser(Member u) {
		user = u;
	}
	public void setVote(int v) {
		votes = v;
	}
	public void incrementVote() {
		votes++;
	}
	public int getVotes() {
		return votes;
	}
	public void clearVotes() {
		votes = 0;
	}
	public void setChannel(PrivateChannel c) {
		this.channel = c;
	}
	public PrivateChannel getChannel() {
		return channel;
	}
	public boolean getCanKill() {
		return canKill;
	}
}
