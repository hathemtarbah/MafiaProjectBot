package Main;

public class Cop extends HasActions{
	
	Cop(){
		this.name = "Cop";
		this.description = "The Cop is the traditional leader of the Village as they obtain new information every night."
				+ " The Cop investigates one person and receives intel as to whether that person is sided with the Village or Mafia."
				+ " The Cop graduated from the top of their class at the police academy and has worked a lifetime to track down their nemesis, the Godfather.";
		this.side = "Village";
		this.objective = "Vote out the Mafia side";
		this.alive = true;
		this.desc = "Choose someone to Investigate tonight";
		this.canKill = false;
	}
	
	
	@Override
	public Roles getSelect() {
		if(select == null) {
			channel.sendMessage("You chose to Investigate no one tonight").queue();
		}
		else if (select != null) {
			channel.sendMessage("You chose to Investigate " + select.getUser().getEffectiveName()).queue();
			if(select instanceof GodFather) {
				channel.sendMessage(select.getUser().getEffectiveName()+" is on the Village side.").queue();
			}
			else {
				channel.sendMessage(select.getUser().getEffectiveName()+" is on the "+select.getSide()+" side.").queue();
			}
		}
		select = null;
		return select;
	}
}
