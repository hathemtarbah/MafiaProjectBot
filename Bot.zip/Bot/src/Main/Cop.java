package Main;

public class Cop extends Roles{
	
	Cop(){
		this.name = "Cop";
		this.description = "The Cop is the traditional leader of the Village as they obtain new information every night."
				+ " The Cop investigates one person and receives intel as to whether that person is sided with the Village or Mafia."
				+ " The Cop graduated from the top of their class at the police academy and has worked a lifetime to track down their nemesis, the Godfather.";
		this.side = "Village";
		this.objective = "Expose the mafias";
		this.alive = true;
	}
}
