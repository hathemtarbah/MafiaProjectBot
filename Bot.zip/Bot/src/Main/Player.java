package Main;

import net.dv8tion.jda.api.entities.Member;

public class Player {
	Member user;
	MafiaRole role;
	
	Player(Member u){
		user = u;
	}
	
	public void setUser(Member m) {
		user = m;
	}
	
	public Member getUser() {
		return user;
	}
	
	public void setRole(MafiaRole r) {
		role = r;
	}
	
	public MafiaRole getRole() {
		return role;
	}
}
