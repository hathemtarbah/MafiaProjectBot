package Main;

import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class DiscordRoles extends ListenerAdapter {
	String[] discordRole = {"Host", "In-game", "Dead", "Alive", "Villager", "Mafia"};
	
	public void onMessageReceived(MessageReceivedEvent event) {
		String prefix = "!";
    	Message msg = event.getMessage();
    	if (msg.getContentRaw().equals(prefix+"start")) {
        	//creates roles
    		RoleMaker(event);
        	
        	event.getGuild().addRoleToMember(event.getMember(), event.getGuild().getRolesByName("Host", true).get(0)).complete();
        	
        	MessageChannel channel = event.getChannel();
        	channel.sendMessage("created role").queue();
        }
    	else if (msg.getContentRaw().equals(prefix+"stop")) {
    		for (Role role : event.getGuild().getRoles()) {
			    if (role.getName().equals("Host")
		    		|| role.getName().equals("In-game")
		    		|| role.getName().equals("Dead")
		    		|| role.getName().equals("Alive")
		    		|| role.getName().equals("Villager")
		    		|| role.getName().equals("Mafia")) {
			    		role.delete().complete();
			    }
			}
    	}
    	else if (msg.getContentRaw().equals(prefix+"role")) {
    		event.getGuild().addRoleToMember(event.getMember(), event.getGuild().getRolesByName("Host", true).get(0)).complete();
    		event.getGuild().addRoleToMember(event.getMember(), event.getGuild().getRolesByName("In-game", true).get(0)).complete();
    		event.getGuild().addRoleToMember(event.getMember(), event.getGuild().getRolesByName("Alive", true).get(0)).complete();
    	}
	}
	
	public void RoleMaker(MessageReceivedEvent event) {
		for (String roleTemp : discordRole) {
			event.getGuild()
        		.createRole()
        		.setName(roleTemp)
        		.queue();
		}
	}
}





/*
 * else if (msg.getContentRaw().equals(prefix+"id")) {
    		for (Role role : event.getGuild().getRoles()) {
			    if (role.getName().equals("Host")) {
			    	MessageChannel channel = event.getChannel();
			    	channel.sendMessage(role.getId()).queue();
			    }
			}
    	}
    	*/
