package Main;

import java.awt.Color;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class Commands extends ListenerAdapter{

	public void onMessageReceived(MessageReceivedEvent event) {
        String prefix = "!";
    	Message msg = event.getMessage();
        if (msg.getContentRaw().equals(prefix + "vote")) {
            MessageChannel channel = event.getChannel();
            channel.sendMessage("this performs the vote action").queue();
        }
        else if (msg.getContentRaw().equals(prefix + "kill")) {
        	MessageChannel channel = event.getChannel();
        	channel.sendMessage("this performs the kill action").queue();
        }
        else if (msg.getContentRaw().contains(prefix + "investigate") ) {
        	MessageChannel channel = event.getChannel();
        	channel.sendMessage("this performs the investigate action").queue();
        }
        else if (msg.getContentRaw().equalsIgnoreCase(prefix + "getrole") ) {
        	EmbedBuilder embed = new EmbedBuilder();
        	/*
        	Set the title:
    	    1. Arg: title as string
    	    2. Arg: URL as string or could also be null
    	    */
        	embed.setTitle("Roles", null);
        	/*
    	    Set the color
        	*/
        	embed.setColor(Color.red);
        	embed.setColor(new Color(0xF40C0C));
        	embed.setColor(new Color(255, 0, 255));
        	/*
    	    Set the text of the Embed:
    	    Arg: text as string
        	*/
        	embed.setDescription("role description");
        	/*
    	    Add fields to embed:
    	    1. Arg: title as string
    	    2. Arg: text as string
    	    3. Arg: inline mode true / false
        	*/
        	embed.addField("Title of field", "test of field", false);
        	/*
    	    Add spacer like field
    	    Arg: inline mode true / false
        	*/
        	embed.addBlankField(false);
        	/*
    	    Add embed author:
    	    1. Arg: name as string
    	    2. Arg: url as string (can be null)
    	    3. Arg: icon url as string (can be null)
        	*/
        	//embed.setAuthor("Haytham Tarbah", null, event.getGuild().getOwner().getUser().getAvatarUrl());
        	/*
    	    Set footer:
    	    1. Arg: text as string
    	    2. icon url as string (can be null)
        	*/
        	embed.setFooter("Footer text", null);
        	/*
    	    Set image:
    	    Arg: image url as string
        	*/
        	embed.setImage("https://ww2.kqed.org/app/uploads/sites/12/2013/12/TheGodfather1a-e1387243558119.jpeg");
        	/*
    	    Set thumbnail image:
    	    Arg: image url as string
        	*/
        	//embed.setThumbnail("https://external-preview.redd.it/VLNX4bJ3qoXK4eb4H0Dh5jl2mD0SweS2XHKfTqX3Qds.png?format=pjpg&auto=webp&s=504482a6803e9badd6476b598ca65041a16430fe");
        	
        	event.getChannel().sendMessageEmbeds(embed.build()).queue();
        }
    }
}
